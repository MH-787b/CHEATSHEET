// background.js - Service worker for Study Sheet
// Handles icon click, hotkey, and API calls with two-tier model routing.
// Easy questions -> Groq (fast), Hard questions -> Claude Haiku (accurate)

// Model config
var GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
var CLAUDE_API_URL = "https://api.anthropic.com/v1/messages";
var FAST_MODEL = "llama-3.3-70b-versatile";
var SMART_MODEL = "claude-haiku-4-5-20251001";

// Key recovery
var _k = "ch34tsh33t";
function _d(a) {
  var s = "";
  for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i] ^ _k.charCodeAt(i % _k.length));
  return s;
}
var _g = [4,27,88,107,45,24,4,106,102,13,40,12,1,118,4,70,48,93,10,39,45,60,97,102,35,52,12,74,81,71,37,49,113,7,7,68,43,87,100,45,20,28,4,67,1,27,5,106,5,31,40,89,3,5,57,70];
var _c = [16,3,30,85,26,7,69,82,67,29,83,91,30,125,70,53,2,103,123,50,58,9,10,2,70,53,46,86,99,48,47,46,86,102,65,64,31,88,100,1,16,55,112,7,27,50,55,82,126,6,83,58,30,119,61,27,63,86,120,63,54,3,71,71,31,6,60,82,68,57,32,58,7,77,89,22,29,118,4,33,17,95,105,123,22,49,4,90,98,38,52,34,74,80,38,22,91,1,68,89,36,88,100,69,64,20,41,114];

// Toggle panel on icon click
chrome.action.onClicked.addListener(function(tab) {
  chrome.tabs.sendMessage(tab.id, { action: "toggle-panel" });
});

// Toggle panel on keyboard shortcut (Alt+L)
chrome.commands.onCommand.addListener(function(command) {
  if (command === "toggle-learning-mode") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggle-panel" });
      }
    });
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "generate") {
    // Capture screenshot immediately while user gesture is still active
    captureScreenshot().then(function(screenshot) {
      return handleGenerate(request.text, request.url, request.mode, request.sigfigs || "3", screenshot);
    })
      .then(function(data) { sendResponse({ success: true, data: data }); })
      .catch(function(err) { sendResponse({ success: false, error: err.message }); });
    return true;
  }
});

// Classify question difficulty to pick the right model
function classifyDifficulty(pageText) {
  var text = pageText.toLowerCase();

  var hardSignals = [
    "bearing", "bearings", "direction", "angle of",
    "explain why", "explain how", "justify", "derive", "prove", "show that",
    "which of the following", "best describes", "most likely",
    "evaluate", "compare", "contrast", "discuss", "assess",
    "sketch", "draw", "describe the",
    "what would happen if", "predict",
    "error", "uncertainty", "significant figures",
    "vector", "resolve", "component",
    "graph", "plot", "relationship between",
    "proportional", "inversely",
    "state and explain", "give a reason",
    "internal resistance", "emf", "e.m.f",
    "in series", "in parallel", "kirchhoff",
    "identical second", "added in series", "added in parallel",
    "ratio", "fraction", "express in terms of",
    "what is the value of", "find the value",
    "two significant", "three significant",
    "challenge 2", "challenge 3",
    "simultaneous", "equation",
    "coulometer", "deposited", "atomic mass",
    "circuit", "voltmeter", "ammeter"
  ];

  for (var i = 0; i < hardSignals.length; i++) {
    if (text.indexOf(hardSignals[i]) !== -1) {
      return "smart";
    }
  }

  return "fast";
}

// Build prompt based on mode
function buildPrompt(mode, pageText, sigfigs) {
  var trimmed = pageText.slice(0, 12000);

  if (mode === "answers") {
    return "Solve every question/problem on this page. You MUST think step-by-step internally before giving answers.\n\n" +
      "IMPORTANT: A screenshot of the page is included. Use it to read any diagrams, circuit diagrams, graphs, figures, tables, or images that contain information needed to solve the questions. Combine the screenshot with the text content below.\n\n" +
      "QUESTION TYPES YOU MUST HANDLE:\n" +
      "- MULTIPLE CHOICE / SELECT ONE: Identify the correct option and state it clearly. Give the full text of the correct answer.\n" +
      "- NUMERICAL / CALCULATION: Solve step-by-step and give the final number with units.\n" +
      "- TRUE/FALSE: State True or False.\n" +
      "- SHORT ANSWER / TEXT: Give the concise correct answer.\n" +
      "- FILL IN THE BLANK: Give the word(s) or value(s) that go in each blank.\n" +
      "- MATCHING: Match each item correctly.\n" +
      "- ANY other question type: Just answer it directly.\n\n" +
      "CRITICAL RULES:\n" +
      "- Look carefully for ALL question types: multiple choice, select one, fill-in-the-blank, true/false, short answer, calculations, etc. Only say 'no questions' if the page genuinely has zero questions or exercises.\n" +
      "- READ THE QUESTION CAREFULLY. Identify EXACTLY what is being asked.\n" +
      "- For multiple choice: read ALL options, pick the correct one, and give the FULL TEXT of the correct option.\n" +
      "- DO NOT stop at intermediate values for calculations. Complete ALL steps to get the FINAL answer.\n" +
      "- ALWAYS include units for numerical answers (g, m, s, V, A, degrees, ohms, etc.) unless dimensionless.\n" +
      "- Be accurate - double-check your reasoning and arithmetic.\n" +
      "- BEARINGS must be given as a NUMBER in DEGREES (e.g. 072, 288), not compass directions like 'North'.\n" +
      "- Match the FORMAT and UNITS the question expects.\n" +
      "- Give numerical answers to " + (sigfigs === "auto" ? "an appropriate number of" : sigfigs) + " significant figures" + (sigfigs === "auto" ? ", matching the precision of the given data" : "") + ". If the question explicitly specifies a different number of s.f. or decimal places, use that instead.\n" +
      "- FOR CIRCUIT PROBLEMS: Draw out the circuit mentally. Identify series vs parallel. Apply Kirchhoff's laws.\n" +
      "- FOR TABLES: Give EACH CELL value separately.\n" +
      "- FOR MULTIPLE BLANKS: Give each one as a separate answer entry.\n" +
      "- FINAL CHECK: Re-read the question. Does your answer directly answer what was asked?\n\n" +
      "Respond ONLY with valid JSON - no markdown, no code fences:\n" +
      '{\n  "answers": [\n    {"topic": "short label for the question", "steps": "brief internal reasoning", "answer": "the correct answer as a plain STRING (for multiple choice: the full text of the correct option). MUST be a string, never an object."}\n  ]\n}\n\n' +
      "Content:\n" + trimmed;
  }

  // "working" mode
  return "You are a friendly, relatable tutor who explains things clearly with a bit of personality. Keep it casual and approachable.\n\n" +
    "IMPORTANT: A screenshot of the page is included. Use it to read any diagrams, circuit diagrams, graphs, figures, tables, or images. Combine the screenshot with the text content below.\n\n" +
    "IMPORTANT: Your job is to ACTUALLY SOLVE any problems, equations, or questions on this page. This includes multiple choice, true/false, short answer, fill-in-the-blank — ANY question type. Show FULL WORKING - every step of the calculation or reasoning. If there are numbers, CRUNCH THEM. For multiple choice, explain WHY the correct option is right and why the others are wrong.\n\n" +
    "CRITICAL: Look carefully for ALL question types — only say there are no questions if the page genuinely has none. READ what the question is asking for. Do NOT stop at intermediate values.\n\n" +
    "- BEARINGS must be given as a NUMBER in DEGREES (e.g. 072, 288), not compass directions.\n" +
    "- Match the FORMAT and UNITS the question expects.\n" +
    "- Give numerical answers to " + (sigfigs === "auto" ? "an appropriate number of" : sigfigs) + " significant figures" + (sigfigs === "auto" ? ", matching the precision of the given data" : "") + ". If the question specifies different, use that.\n" +
    "- ALWAYS include units.\n\n" +
    "Look at the page content and:\n" +
    "1. Identify every question, problem, or exercise on the page\n" +
    "2. Identify EXACTLY what quantity each question asks for\n" +
    "3. Solve each one with FULL step-by-step working\n" +
    "4. Verify your final answer is the quantity that was actually asked for\n" +
    "5. If the page is educational content with no specific questions, break down the key concepts\n\n" +
    "Respond ONLY with valid JSON - no markdown, no code fences:\n" +
    '{\n' +
    '  "vibe": "a one-liner roasting the topic or homework (be funny and unhinged)",\n' +
    '  "breakdown": [\n' +
    '    {\n' +
    '      "topic": "short label for the question/problem",\n' +
    '      "explanation": "what the question is actually asking, in gen z speak",\n' +
    '      "working": "FULL step-by-step solution with every calculation shown. Use gen z speak but be mathematically rigorous.",\n' +
    '      "answer": "THE FINAL NUMERICAL/SPECIFIC ANSWER WITH UNITS"\n' +
    '    }\n' +
    '  ],\n' +
    '  "tldr": "a brutally short gen z summary in 2-3 sentences",\n' +
    '  "copypasta": "a clean, teacher-safe solution you could paste into an assignment"\n' +
    '}\n\n' +
    "Solve EVERY question/problem you can find. Accuracy is critical.\n\n" +
    "Content:\n" + trimmed;
}

// Call Groq API
async function callGroq(prompt, maxTokens) {
  var body = {
    model: FAST_MODEL,
    max_tokens: maxTokens,
    temperature: 0,
    messages: [{ role: "user", content: prompt }]
  };

  var response = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + _d(_g)
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    var errBody = await response.text();
    if (response.status === 429) throw new Error("rate limited");
    throw new Error("Groq error " + response.status + ": " + errBody);
  }

  var result = await response.json();
  return result.choices[0].message.content;
}

// Capture screenshot of active tab
async function captureScreenshot() {
  try {
    var dataUrl = await chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 85 });
    var base64 = dataUrl.split(",")[1];
    console.log("Screenshot captured: " + Math.round(base64.length / 1024) + "KB");
    return base64;
  } catch (e) {
    console.log("Screenshot capture failed: " + e.message);
    return null;
  }
}

// Call Claude API (supports optional screenshot)
async function callClaude(prompt, maxTokens, screenshotBase64) {
  var content = [];

  // Add screenshot if available
  if (screenshotBase64) {
    content.push({
      type: "image",
      source: {
        type: "base64",
        media_type: "image/jpeg",
        data: screenshotBase64
      }
    });
  }

  content.push({ type: "text", text: prompt });

  var body = {
    model: SMART_MODEL,
    max_tokens: maxTokens,
    messages: [{ role: "user", content: content }]
  };

  var response = await fetch(CLAUDE_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": _d(_c),
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    var errBody = await response.text();
    if (response.status === 429) throw new Error("rate limited");
    throw new Error("Claude error " + response.status + ": " + errBody);
  }

  var result = await response.json();
  return result.content[0].text;
}

// Parse JSON from model response
function parseJSON(text) {
  text = text.replace(/<think>[\s\S]*?<\/think>/g, "").trim();
  text = text.replace(/```json\s*/g, "").replace(/```\s*/g, "").trim();

  var depth = 0;
  var start = -1;
  var end = -1;
  for (var i = 0; i < text.length; i++) {
    if (text[i] === "{") {
      if (depth === 0) start = i;
      depth++;
    } else if (text[i] === "}") {
      depth--;
      if (depth === 0) { end = i; break; }
    }
  }

  if (start === -1 || end === -1) {
    throw new Error("no_json");
  }

  return JSON.parse(text.slice(start, end + 1));
}

// Main handler
async function handleGenerate(pageText, _pageUrl, mode, sigfigs, screenshot) {
  var prompt = buildPrompt(mode, pageText, sigfigs);
  var difficulty = classifyDifficulty(pageText);
  var maxTokens = mode === "answers" ? 2048 : 4096;

  console.log("Difficulty: " + difficulty + (screenshot ? " (with screenshot)" : " (text only)"));

  // Hard questions -> Claude with screenshot, fallback to Groq
  if (difficulty === "smart") {
    try {
      console.log("Using Claude Haiku for hard question");
      var rawText = await callClaude(prompt, maxTokens, screenshot);
      var data = parseJSON(rawText);
      data._mode = mode;
      data._model = "claude-haiku";
      return data;
    } catch (e) {
      console.log("Claude failed (" + e.message + "), falling back to Groq");
    }
  }

  // Easy questions -> try Groq first, but if it fails or page has images, use Claude with screenshot
  try {
    console.log("Using Groq for question");
    var rawText = await callGroq(prompt, maxTokens);
    var data = parseJSON(rawText);
    data._mode = mode;
    data._model = "groq-llama";
    return data;
  } catch (e) {
    // If Groq fails and we have a screenshot, try Claude as fallback
    if (screenshot) {
      console.log("Groq failed (" + e.message + "), falling back to Claude with screenshot");
      var rawText = await callClaude(prompt, maxTokens, screenshot);
      var data = parseJSON(rawText);
      data._mode = mode;
      data._model = "claude-haiku";
      return data;
    }
    throw e;
  }
}
