// content.js — Injected into every page.
// Manages the overlay panel, mode switching, and rendering.

let panelInjected = false;
let panelVisible = false;
let currentMode = "answers"; // "answers" or "working"
let currentSigFigs = "3"; // "auto", "1"-"5"
let loadingInterval = null;
const DAILY_LIMIT = 20;

const loadingMessages = [
  "thinking...",
  "crunching numbers",
  "reading the page",
  "almost there...",
  "working on it",
  "one sec",
];

function startLoadingMessages() {
  const el = document.getElementById("lm-loading-text");
  let i = 0;
  el.textContent = loadingMessages[0];
  loadingInterval = setInterval(() => {
    i = (i + 1) % loadingMessages.length;
    el.textContent = loadingMessages[i];
  }, 4000);

  // Robot thinking mode - show thought bubble
  const robot = document.getElementById("lm-robot");
  if (robot) robot.classList.add("lm-robot-thinking");
  const bubble = document.getElementById("lm-thought-bubble");
  if (bubble) bubble.classList.add("lm-thought-visible");
  const status = document.getElementById("lm-robot-status");
  if (status) status.textContent = "hmm...";
}

function stopLoadingMessages() {
  if (loadingInterval) {
    clearInterval(loadingInterval);
    loadingInterval = null;
  }

  // Stop robot thinking - hide thought bubble
  const robot = document.getElementById("lm-robot");
  if (robot) robot.classList.remove("lm-robot-thinking");
  const bubble = document.getElementById("lm-thought-bubble");
  if (bubble) bubble.classList.remove("lm-thought-visible");
}

// ─── Listen for toggle from background ───────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "toggle-panel") {
    if (!panelInjected) {
      injectPanel();
      panelInjected = true;
    }
    togglePanel();
  }
});

// ─── Extract main readable content ───────────────────────────────────────────
function extractPageText() {
  const preferred = document.querySelector("article") || document.querySelector("main");
  if (preferred) return preferred.innerText.trim();

  const clone = document.body.cloneNode(true);
  const noisy = clone.querySelectorAll(
    "nav, header, footer, aside, .sidebar, .nav, .menu, .ad, .ads, .advertisement, " +
    ".comments, .comment, #comments, script, style, noscript, iframe, svg, " +
    "[role='navigation'], [role='banner'], [role='complementary'], [role='contentinfo']"
  );
  noisy.forEach((el) => el.remove());
  return clone.innerText.trim();
}

// ─── Inject the panel ────────────────────────────────────────────────────────
function injectPanel() {
  const panel = document.createElement("div");
  panel.id = "lm-panel";
  panel.innerHTML = `
    <div id="lm-panel-inner">
      <div id="lm-header">
        <div>
          <span id="lm-title">𝙎𝙏𝙐𝘿𝙔 𝙎𝙃𝙀𝙀𝙏</span>
        </div>
        <button id="lm-close" title="Hide Panel">&times;</button>
      </div>

      <div id="lm-robot-wrapper">
        <div id="lm-robot">
          <div id="lm-robot-antenna">
            <div id="lm-robot-antenna-ball"></div>
            <div id="lm-robot-antenna-stick"></div>
          </div>
          <div id="lm-robot-head">
            <div id="lm-robot-eyes">
              <div class="lm-robot-eye"><div class="lm-robot-pupil"></div></div>
              <div class="lm-robot-eye"><div class="lm-robot-pupil"></div></div>
            </div>
            <div id="lm-robot-mouth"></div>
          </div>
          <div id="lm-robot-body">
            <div id="lm-robot-screen"></div>
          </div>
          <div id="lm-robot-feet">
            <div class="lm-robot-foot"></div>
            <div class="lm-robot-foot"></div>
          </div>
        </div>
        <div id="lm-thought-bubble">
          <span id="lm-robot-status">hi :)</span>
          <div class="lm-thought-dot lm-thought-dot-1"></div>
          <div class="lm-thought-dot lm-thought-dot-2"></div>
        </div>
      </div>

      <div id="lm-mode-toggle">
        <button id="lm-mode-answers" class="lm-mode-btn lm-mode-active" data-mode="answers">just answers</button>
        <button id="lm-mode-working" class="lm-mode-btn" data-mode="working">with working</button>
      </div>

      <div id="lm-sigfig">
        <label id="lm-sigfig-label">sig figs</label>
        <div id="lm-sigfig-btns">
          <button class="lm-sf-btn" data-sf="auto">auto</button>
          <button class="lm-sf-btn" data-sf="1">1</button>
          <button class="lm-sf-btn" data-sf="2">2</button>
          <button class="lm-sf-btn lm-sf-active" data-sf="3">3</button>
          <button class="lm-sf-btn" data-sf="4">4</button>
          <button class="lm-sf-btn" data-sf="5">5</button>
        </div>
      </div>

      <div id="lm-actions">
        <button id="lm-generate" class="lm-btn lm-btn-main">solve this page</button>
      </div>

      <div id="lm-loading" class="lm-hidden">
        <p id="lm-loading-text"></p>
      </div>

      <div id="lm-content" class="lm-hidden"></div>

      <div id="lm-error" class="lm-hidden">
        <p id="lm-error-msg"></p>
      </div>

      <div id="lm-footer">
        <div id="lm-footer-top">
          <button id="lm-theme-toggle" title="Toggle light/dark mode">
            <span id="lm-theme-icon">&#9789;</span>
          </button>
        </div>
        <div id="lm-usage">
          <div id="lm-usage-label">
            <span id="lm-usage-text">12 / 20 uses today</span>
            <a id="lm-upgrade" href="https://mh-787b.github.io/CHEATSHEET/" target="_blank">upgrade</a>
          </div>
          <div id="lm-usage-bar">
            <div id="lm-usage-fill"></div>
          </div>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // Wire up events
  document.getElementById("lm-close").addEventListener("click", togglePanel);
  document.getElementById("lm-generate").addEventListener("click", handleGenerate);

  // Mode toggle buttons
  document.querySelectorAll(".lm-mode-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".lm-mode-btn").forEach((b) => b.classList.remove("lm-mode-active"));
      btn.classList.add("lm-mode-active");
      currentMode = btn.dataset.mode;

      const genBtn = document.getElementById("lm-generate");
      genBtn.textContent = currentMode === "answers" ? "solve this page" : "explain it to me";
    });
  });

  // Sig figs toggle
  document.querySelectorAll(".lm-sf-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".lm-sf-btn").forEach((b) => b.classList.remove("lm-sf-active"));
      btn.classList.add("lm-sf-active");
      currentSigFigs = btn.dataset.sf;
    });
  });

  // Theme toggle
  document.getElementById("lm-theme-toggle").addEventListener("click", () => {
    const panel = document.getElementById("lm-panel");
    panel.classList.toggle("lm-light");
    const icon = document.getElementById("lm-theme-icon");
    icon.innerHTML = panel.classList.contains("lm-light") ? "&#9790;" : "&#9789;";
  });

  // Usage tracking
  updateUsageBar();

  // Robot eye tracking
  document.addEventListener("mousemove", (e) => {
    const pupils = document.querySelectorAll(".lm-robot-pupil");
    pupils.forEach((pupil) => {
      const eye = pupil.parentElement;
      const rect = eye.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const dx = e.clientX - cx;
      const dy = e.clientY - cy;
      const angle = Math.atan2(dy, dx);
      const dist = Math.min(Math.sqrt(dx * dx + dy * dy), 200);
      const maxMove = 3;
      const move = (dist / 200) * maxMove;
      pupil.style.transform = `translate(${Math.cos(angle) * move}px, ${Math.sin(angle) * move}px)`;
    });
  });
}

// ─── Toggle panel visibility ─────────────────────────────────────────────────
function togglePanel() {
  const panel = document.getElementById("lm-panel");
  panelVisible = !panelVisible;
  panel.classList.toggle("lm-open", panelVisible);
}

// ─── Generate content ────────────────────────────────────────────────────────
async function handleGenerate() {
  const loading = document.getElementById("lm-loading");
  const content = document.getElementById("lm-content");
  const error = document.getElementById("lm-error");

  loading.classList.remove("lm-hidden");
  content.classList.add("lm-hidden");
  error.classList.add("lm-hidden");
  startLoadingMessages();

  const pageText = extractPageText();

  if (!pageText || pageText.length < 50) {
    showError("There's not enough content on this page to work with.");
    return;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      action: "generate",
      text: pageText,
      url: window.location.href,
      mode: currentMode,
      sigfigs: currentSigFigs
    });

    stopLoadingMessages();
    loading.classList.add("lm-hidden");

    if (!response || !response.success) {
      showError((response && response.error) || "Something went wrong. Try reloading the page.");
      return;
    }

    if (currentMode === "answers") {
      renderAnswers(response.data);
    } else {
      renderWorking(response.data);
    }

    content.classList.remove("lm-hidden");
    incrementUsage();
  } catch (err) {
    stopLoadingMessages();
    loading.classList.add("lm-hidden");
    showError(err.message);
  }
}

// ─── Render "Just Answers" mode ──────────────────────────────────────────────
function renderAnswers(data) {
  const content = document.getElementById("lm-content");
  content.innerHTML = "";

  if (data.answers) {
    data.answers.forEach((a) => {
      const card = document.createElement("div");
      card.className = "lm-card";
      card.innerHTML = `
        <p class="lm-card-label">${escapeHtml(a.topic)}</p>
        <p class="lm-card-answer">${escapeHtml(a.answer)}</p>
      `;
      content.appendChild(card);
    });
  }
}

// ─── Render "With Working" mode ──────────────────────────────────────────────
function renderWorking(data) {
  const content = document.getElementById("lm-content");
  content.innerHTML = "";

  // Vibe check / roast
  if (data.vibe) {
    const vibe = document.createElement("div");
    vibe.className = "lm-vibe";
    vibe.textContent = data.vibe;
    content.appendChild(vibe);
  }

  // Breakdowns
  if (data.breakdown) {
    const section = document.createElement("div");
    section.className = "lm-section";
    section.innerHTML = `<h3 class="lm-section-title">the breakdown</h3>`;

    data.breakdown.forEach((item) => {
      const card = document.createElement("div");
      card.className = "lm-card lm-card-working";
      card.innerHTML = `
        <p class="lm-card-label">${escapeHtml(item.topic)}</p>
        <p class="lm-card-explanation">${escapeHtml(item.explanation)}</p>
        <div class="lm-working-toggle">
          <button class="lm-show-working-btn">show working</button>
          <div class="lm-working-content lm-hidden">
            <p class="lm-working-text">${escapeHtml(item.working)}</p>
          </div>
        </div>
        <div class="lm-final-answer">
          <span class="lm-answer-label">answer:</span> ${escapeHtml(item.answer)}
        </div>
      `;

      // Toggle working visibility
      const btn = card.querySelector(".lm-show-working-btn");
      const workingContent = card.querySelector(".lm-working-content");
      btn.addEventListener("click", () => {
        workingContent.classList.toggle("lm-hidden");
        btn.textContent = workingContent.classList.contains("lm-hidden") ? "show working" : "hide working";
      });

      section.appendChild(card);
    });
    content.appendChild(section);
  }

  // TLDR
  if (data.tldr) {
    const tldr = document.createElement("div");
    tldr.className = "lm-section";
    tldr.innerHTML = `
      <h3 class="lm-section-title">tldr</h3>
      <p class="lm-tldr">${escapeHtml(data.tldr)}</p>
    `;
    content.appendChild(tldr);
  }

  // Copypasta
  if (data.copypasta) {
    renderCopypasta(content, data.copypasta);
  }
}

// ─── Copypasta section with copy button ──────────────────────────────────────
function renderCopypasta(container, text) {
  const section = document.createElement("div");
  section.className = "lm-section lm-copypasta-section";
  section.innerHTML = `
    <h3 class="lm-section-title">clean solution</h3>
    <div class="lm-copypasta-box">
      <p class="lm-copypasta-text">${escapeHtml(text)}</p>
      <button class="lm-copy-btn">copy</button>
    </div>
  `;

  section.querySelector(".lm-copy-btn").addEventListener("click", function () {
    navigator.clipboard.writeText(text).then(() => {
      this.textContent = "copied!";
      setTimeout(() => { this.textContent = "copy"; }, 1500);
    });
  });

  container.appendChild(section);
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function showError(msg) {
  const loading = document.getElementById("lm-loading");
  const error = document.getElementById("lm-error");
  const errorMsg = document.getElementById("lm-error-msg");
  loading.classList.add("lm-hidden");
  error.classList.remove("lm-hidden");
  errorMsg.textContent = msg;
}

function escapeHtml(val) {
  if (val === null || val === undefined) return "";
  if (typeof val === "object") val = JSON.stringify(val);
  const div = document.createElement("div");
  div.textContent = String(val);
  return div.innerHTML;
}

// ─── Usage tracking ──────────────────────────────────────────────────────────
function getTodayKey() {
  return `lm_usage_${new Date().toISOString().slice(0, 10)}`;
}

async function getUsageCount() {
  const key = getTodayKey();
  const result = await chrome.storage.local.get(key);
  return result[key] || 0;
}

async function incrementUsage() {
  const key = getTodayKey();
  const count = await getUsageCount();
  await chrome.storage.local.set({ [key]: count + 1 });
  updateUsageBar();
}

async function updateUsageBar() {
  const count = await getUsageCount();
  const pct = Math.min((count / DAILY_LIMIT) * 100, 100);
  const text = document.getElementById("lm-usage-text");
  const fill = document.getElementById("lm-usage-fill");
  if (text) text.textContent = `${count} / ${DAILY_LIMIT} uses today`;
  if (fill) fill.style.width = `${pct}%`;
}
