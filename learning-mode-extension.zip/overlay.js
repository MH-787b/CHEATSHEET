// overlay.js — Optional helper module.
// All overlay logic is embedded in content.js for simplicity with Manifest V3.
// This file is reserved for future modularisation (e.g. if you move to a build
// step with ES modules or want to split rendering logic).
//
// Currently unused — content.js handles panel injection, rendering, and quiz
// mode directly so the extension works without any bundler.
